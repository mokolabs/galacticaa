/* If you're reading this, welcome.

   Feel free to learn from this widget, but do not copy code without permission.
   All rights reserved. � 2005, Galacticaa.net / Mokolabs, Inc.
   
   Battlestar Galactica � SciFi, 2005. */


// Set version
var v = '2.1';

// Set default values
var xmlReq;
var timerInterval = null;
var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};
var show_prefs = null;
var display_clock = 'yes';

// Handle current widget state
if (window.widget) {
	widget.onshow = onshow;
	widget.onhide = onhide;
	widget.onremove = onremove;
}


/* FUNCTIONS */

function setup() {

	// Show front panel on first load
	front.style.display = 'block';
	back.style.display = 'none';
	upgrade.style.display = 'none';
	
	// Set default values
	document.getElementById('magic_popup').selectedIndex = 4;
	widget.setPreferenceForKey('22','magicHour');
	widget.setPreferenceForKey('yes','displayClock');
}

function onshow() {

	// Check for new episode info
	xmlReq = new XMLHttpRequest();
	xmlReq.onreadystatechange = processReqChange;
	xmlReq.setRequestHeader('Cache-Control', 'no-cache');
	var ts = (new Date).getTime();
	var theURL = '/widget/feed.php?ts=' + ts + '&v=' + v;
	xmlReq.open('GET', theURL, true);
	xmlReq.send(null);

	// Set magic hour values for front panel text and back panel popup
	magicHour = widget.preferenceForKey('magicHour');
	if (magicHour && magicHour.length > 0) {
		if (magicHour == '18') {
			document.getElementById('magic_popup').selectedIndex = 0;
			document.getElementById('magic_hour').innerHTML = '6pm';
		}
		if (magicHour == '19') {
			document.getElementById('magic_popup').selectedIndex = 1;
			document.getElementById('magic_hour').innerHTML = '7pm';
		}
		if (magicHour == '20') {
			document.getElementById('magic_popup').selectedIndex = 2;
			document.getElementById('magic_hour').innerHTML = '8pm';
		}
		if (magicHour == '21') {
			document.getElementById('magic_popup').selectedIndex = 3;
			document.getElementById('magic_hour').innerHTML = '9pm';
		}
		if (magicHour == '22') {
			document.getElementById('magic_popup').selectedIndex = 4;
			document.getElementById('magic_hour').innerHTML = '10pm';
		}
	}

	// Show clock if requested
	var displayClock = widget.preferenceForKey('displayClock');
	if (episode_airdate_y != null && 
		episode_airdate_m != null && 
		episode_airdate_d != null && 
		displayClock == 'yes') {
		set_countdown(episode_airdate_y,episode_airdate_m,episode_airdate_d,magicHour,00,00);
		timerInterval = setInterval('countdown();', 1000);
	}

}

function onhide() {

	// Pause countdown click (if active)
	if (timerInterval != null) {
		clearInterval(timerInterval);
		timerInterval = null;
	}

}

function onremove() {

	// Erase preferences
	widget.setPreferenceForKey(null,'displayClock');
	widget.setPreferenceForKey(null,'magicHour');

}

function showPrefs() {

	// Switch to back panel
	if (window.widget) {
	    widget.prepareForTransition('ToBack'); 
	    setTimeout ('widget.performTransition();', 0);
	}
	document.getElementById('front').style.display = 'none';
	document.getElementById('back').style.display = 'block';
	document.getElementById('upgrade').style.display = 'none';
	document.getElementById('done_button').src = 'done.png';

	// Set show_prefs flag
	show_prefs = 'yes';

} 

function hidePrefs() {

	// Play sound
	document.soundEmbed.Play();

	// Switch to front panel
	document.getElementById('front').style.display = 'block';
	document.getElementById('back').style.display = 'none';
	document.getElementById('upgrade').style.display = 'none';
	if (window.widget) {
	    widget.prepareForTransition('ToFront'); 
	    setTimeout ('widget.performTransition();', 0);
	}
	flipShown = true;
	mouseexit(event);
	document.getElementById('fliprollie').style.display = 'none';

	// Show clock if requested
	if (display_clock == 'yes') {
		widget.setPreferenceForKey('yes','displayClock');
	} else {
		widget.setPreferenceForKey('no','displayClock');
	}

	// Set show_prefs flag
	show_prefs = 'no';

}

function change_hour(elem) {

	// Load magic hour popup selection
	var magic = document.getElementById('magic_hour');

	// Store and display new magic hour value
	var magic_text = document.getElementById('magic_popup_text');
	var magicHour = null;
	switch(elem.selectedIndex) {
		case 0:
			magicHour = 18;
			magic.innerHTML = '6pm';
			magic_text.innerHTML = '6 pm';
			break;
		case 1:
			magicHour = 19;
			magic.innerHTML = '7pm';
			magic_text.innerHTML = '7 pm';
			break;
		case 2:
			magicHour = 20;
			magic.innerHTML = '8pm';
			magic_text.innerHTML = '8 pm';
			break;
		case 3:
			magicHour = 21;
			magic.innerHTML = '9pm';
			magic_text.innerHTML = '9 pm';
			break;
		case 4:
			magicHour = 22;
			magic.innerHTML = '10pm';
			magic_text.innerHTML = '10 pm';
			break;
	}
	widget.setPreferenceForKey(magicHour,'magicHour');

	// Reset countdown clock
	set_countdown(episode_airdate_y,episode_airdate_m,episode_airdate_d,magicHour,00,00);
	timerInterval = setInterval('countdown();', 1000);

}

function set_countdown(theyear,themonth,theday,thehour,themin,thesec) {

	// Set countdown variables
	yr = theyear;
	mo = themonth;
	da = theday;
	hr = thehour;
	min = themin;
	sec = thesec;

}

function countdown() {
/* Countdown adapted from Dynamic Countdown Script II...
http://www.dynamicdrive.com/dynamicindex6/dhtmlcount2.htm
Author: Chuck Winrich (winrich@babson.edu), based on a countdown script by Dynamic Drive */

	// Load display clock value
	var displayClock = widget.preferenceForKey('displayClock');

	// Calculate time until next episode
	var today = new Date();
	var todayy = today.getYear();
	if (todayy < 1000)
		todayy += 1900;
	var todaym = today.getMonth();
	var todayd = today.getDate();
	var todayh = today.getHours();
	var todaymin = today.getMinutes();
	var todaysec = today.getSeconds();
	var montharray = new Array('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	var todaystring = montharray[todaym]+' '+todayd+', '+todayy+' '+todayh+':'+todaymin+':'+todaysec;
	futurestring = montharray[mo-1]+' '+da+', '+yr+' '+hr+':'+min+':'+sec;
	dd = Date.parse(futurestring)-Date.parse(todaystring);
	dday = Math.floor(dd/(60*60*1000*24)*1);
	dhour = Math.floor((dd%(60*60*1000*24))/(60*60*1000)*1);
	dmin = Math.floor(((dd%(60*60*1000*24))%(60*60*1000))/(60*1000)*1);
	dsec = Math.floor((((dd%(60*60*1000*24))%(60*60*1000))%(60*1000))/1000*1);

	// If clock is active, update clock text
	if (displayClock == 'yes') {
		var clocktext = dday;
		clocktext += ' <span>days</span> ';
		clocktext += dhour;
		clocktext += ' <span>hrs</span> ';
		clocktext += dmin;
		clocktext += ' <span>mins</span> ';
		clocktext += dsec;
		clocktext += ' <span>secs</span>';
		document.getElementById('countdown').innerHTML = clocktext;
		return;

	// If clock is inactive, set to null
	} else {
		document.getElementById('countdown').innerHTML = '';
	}

}

function processReqChange() {

	// Initialize variables
	var episode_name;
	var episode_type;
	var episode_image;
	var episode_number;
	var episode_image;
	var episode_summary;
	var episode_airdate;
	var episode_airdate_full;
	var episode_summary;
	var new_version;
	var upgrade_message;

	// Load feed data & update widget
	if (xmlReq.readyState == 4) {
		if (xmlReq.status == 200) {

			// Load the feed
			var galacticaa = xmlReq.responseXML.getElementsByTagName('galacticaa')[0];

			// Load feed data into variables
			episode_name = galacticaa.getElementsByTagName('episode_name')[0].item(0).data;
			episode_type = galacticaa.getElementsByTagName('episode_type')[0].item(0).data;
			episode_image = galacticaa.getElementsByTagName('episode_image')[0].item(0).data;
			episode_number = galacticaa.getElementsByTagName('episode_number')[0].item(0).data;
			episode_summary = galacticaa.getElementsByTagName('episode_summary')[0].item(0).data;
			episode_airdate_m = galacticaa.getElementsByTagName('episode_airdate_m')[0].item(0).data;
			episode_airdate_d = galacticaa.getElementsByTagName('episode_airdate_d')[0].item(0).data;
			episode_airdate_y = galacticaa.getElementsByTagName('episode_airdate_y')[0].item(0).data;
			episode_airdate_full = galacticaa.getElementsByTagName('episode_airdate_full')[0].item(0).data;
			new_version = galacticaa.getElementsByTagName('new_version')[0].item(0).data;
			upgrade_message = galacticaa.getElementsByTagName('upgrade_message')[0].item(0).data;

			// Update front panel
			document.getElementById('episode_name').innerHTML = episode_name + ' <span id="episode_type">(' + episode_type + ')';
			if (episode_image == 'yes') {
				document.getElementById('episode_image').innerHTML = '<img src="/widget/images/' + episode_number + '.png" alt="" />';
			} else {
				document.getElementById('episode_image').innerHTML = '';
			}
			document.getElementById('episode_summary').innerHTML = episode_summary;
			document.getElementById('episode_airdate_full').innerHTML = episode_airdate_full + '/';

			// If new version is available, show upgrade message
			if (new_version == 'yes') {
				back.style.display = 'none';
				front.style.display = 'none';
				upgrade.style.display = 'block';
				document.getElementById('upgrade_message').innerHTML = upgrade_message;
			}

			// If new version is not available, show currently selected panel
			if (new_version == 'no') {
				upgrade.style.display = 'none';
				if (show_prefs == 'yes') {
					 document.getElementById('front').style.display = 'none';
					 document.getElementById('back').style.display = 'block';
				}
				if (show_prefs == 'no') {
					document.getElementById('front').style.display = 'block';
					document.getElementById('back').style.display = 'none';
				}
			}

			// Update countdown clock
			set_countdown(episode_airdate_y,episode_airdate_m,episode_airdate_d,magicHour,00,00);
			if (timerInterval == null) {
				timerInterval = setInterval('countdown();', 1000);
			}
		}
	}
}

function toggle_checkbox() {

	// If clock is activated, set checkbox to checked
	if (display_clock == 'no') {
		display_clock = 'yes';
		document.getElementById('checkbox').src = 'checkbox_pressed.png';

	// If close is not actived, show plain checkbox
	} else {
		display_clock = 'no';
		document.getElementById('checkbox').src = 'checkbox.png';
	}
}

function sendform() {
	document.getElementById('upgrade_link_img').src = 'download_pressed.png';
	setTimeout('redirect();', 1000);
}

function redirect() {
	var url = 'http://galacticaa.net?v=' + v; 
	if (window.widget) {
		widget.openURL(url);
	} else {
		window.location = url;
	}
	return false;
}

function mousemove (event) {
// mousemove() is the event handle assigned to the onmousemove property on the front div of the widget. 
// It is triggered whenever a mouse is moved within the bounds of your widget.  It prepares the
// preference flipper fade and then calls animate() to performs the animation.

	if (!flipShown)	// if the preferences flipper is not already showing...
	{
		if (animation.timer != null)								// reset the animation timer value
		{
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		var starttime = (new Date).getTime() - 13; 					// set it back one frame
		animation.duration = 500;									// animation time, in ms
		animation.starttime = starttime;							// specify the start time
		animation.firstElement = document.getElementById ('flip');	// specify the element to fade
		animation.timer = setInterval ('animate();', 13);			// set the animation function
		animation.from = animation.now;								// beginning opacity (not ness. 0)
		animation.to = 1.0;											// final opacity
		animate();													// begin animation
		flipShown = true;											// mark the flipper as animated
	}
}

function mouseexit (event) {
// mouseexit() is the opposite of mousemove() in that it preps the preferences flipper
// to disappear.  It adds the appropriate values to the animation data structure and sets the animation in motion.

	if (flipShown)
	{
		// fade in the flip widget
		if (animation.timer != null)
		{
			clearInterval (animation.timer);
			animation.timer  = null;
		}
		
		var starttime = (new Date).getTime() - 13;
		
		animation.duration = 500;
		animation.starttime = starttime;
		animation.firstElement = document.getElementById ('flip');
		animation.timer = setInterval ('animate();', 13);
		animation.from = animation.now;
		animation.to = 0.0;
		animate();
		flipShown = false;
	}
}

function enterflip(event) {
	document.getElementById('fliprollie').style.display = 'block';
}

function exitflip(event) {
	document.getElementById('fliprollie').style.display = 'none';
}

function animate() {
/* animate() performs the fade animation for the preferences flipper */

	var T;
	var ease;
	var time = (new Date).getTime();
		
	
	T = limit_3(time-animation.starttime, 0, animation.duration);
	
	if (T >= animation.duration)
	{
		clearInterval (animation.timer);
		animation.timer = null;
		animation.now = animation.to;
	}
	else
	{
		ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
		animation.now = computeNextFloat (animation.from, animation.to, ease);
	}
	
	animation.firstElement.style.opacity = animation.now;
}

function limit_3 (a, b, c) {
	return a < b ? b : (a > c ? c : a);
}

function computeNextFloat (from, to, ease) {
	return from + (to - from) * ease;
}